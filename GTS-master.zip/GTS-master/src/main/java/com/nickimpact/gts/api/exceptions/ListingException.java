package com.nickimpact.gts.api.exceptions;

/**
 * (Some note will go here)
 *
 * @author NickImpact
 */
public class ListingException extends RuntimeException {
}
