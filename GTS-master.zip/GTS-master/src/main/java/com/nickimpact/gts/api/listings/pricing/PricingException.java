package com.nickimpact.gts.api.listings.pricing;

/**
 * (Some note will go here)
 *
 * @author NickImpact
 */
public class PricingException extends Exception {

	public PricingException(String message) {
		super(message);
	}
}
