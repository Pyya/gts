package com.nickimpact.gts.api.listings.pricing;

/**
 * (Some note will go here)
 *
 * @author NickImpact
 */
public class RewardException extends Exception {

	public RewardException(String message) {
		super(message);
	}
}
