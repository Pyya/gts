package com.nickimpact.gts.api.time;

/**
 * (Some note will go here)
 *
 * @author NickImpact
 */
public class InvalidTimeException extends Exception { }
