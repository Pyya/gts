package com.nickimpact.gts.exceptions;

/**
 * (Some note will go here)
 *
 * @author NickImpact
 */
public class GiveException extends Exception {

	public GiveException(String message) {
		super(message);
	}
}
