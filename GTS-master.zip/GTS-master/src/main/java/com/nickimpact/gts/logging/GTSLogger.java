package com.nickimpact.gts.logging;

/**
 * (Some note will go here)
 *
 * @author NickImpact
 */
public class GTSLogger {


}
