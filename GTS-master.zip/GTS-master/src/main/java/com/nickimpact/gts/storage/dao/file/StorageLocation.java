package com.nickimpact.gts.storage.dao.file;

/**
 * (Some note will go here)
 *
 * @author NickImpact
 */
public enum StorageLocation {

	LISTINGS, LOGS,
}
